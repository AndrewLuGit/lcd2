#ifndef _LCD2_BASE_H_
#define _LCD2_BASE_H_

namespace lcd2 {
void initialize(const char* autons[], int default_auto, const char* page_titles[]);
}

#endif